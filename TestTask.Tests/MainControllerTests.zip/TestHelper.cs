﻿using TestTask.DAL.Repositories;
using TestTask.DAL;
using Moq;
using TestTask.Controllers;
using Microsoft.EntityFrameworkCore;

namespace TestTask.TestProject1
{
    internal static class TestHelper
    {
        public static MainController GetMainController(TestTaskDbContext dbContext) => new() { };

        public static Mock<TestTaskDbContext> GetDbContextMock() =>
            new(
                new DbContextOptionsBuilder<TestTaskDbContext>()
                    .UseInMemoryDatabase("Test")
                    .Options)
            {
                CallBase = true
            };

        private static Mock<HttpContext> GetHttpContextMock(TestTaskDbContext dbContext)
        {
            var httpContextMock = new Mock<HttpContext> { CallBase = true };
            httpContextMock
                .Setup(context => context.RequestServices.GetService(typeof(TestTaskDbContext)))
                .Returns(dbContext);

            httpContextMock
                .Setup(context => context.RequestServices.GetService(typeof(ContractRepository)))
                .Returns(new ContractRepository(dbContext));

            var requestMock = new Mock<HttpRequest>();
            var headers = new HeaderDictionary();
            requestMock
                .Setup(request => request.Headers)
                .Returns(headers);
            httpContextMock
                .Setup(context => context.Request)
                .Returns(requestMock.Object);

            return httpContextMock;
        }
    }
}
