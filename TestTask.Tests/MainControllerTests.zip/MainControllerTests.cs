using NUnit.Framework;
using Microsoft.EntityFrameworkCore;
using Moq;
using TestTask.DAL;
using TestTask.Controllers;

namespace TestTask.TestProject1
{
    public class Tests
    {
        private Mock<TestTaskDbContext> _dbContextMock;
        private MainController _mainControllerMock;

        [OneTimeSetUp]
        public void Setup()
        {
            _dbContextMock = TestHelper.GetDbContextMock();
            _dbContextMock.Object.Database.EnsureCreated();
            _mainControllerMock = TestHelper.GetMainController(_dbContextMock.Object);
            _mainControllerMock.HttpContext.Request.Headers.Add("Key", string.Empty);
        }

        [OneTimeTearDown]
        public void TearDown() 
        {
            _dbContextMock.Object.Database.EnsureDeleted();
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }

        
    }
}